﻿using VeloBrawl.General.Cloud;
using VeloBrawl.General.Network;
using VeloBrawl.Logic.Database;
using VeloBrawl.Proxy.Cloud;
using VeloBrawl.Proxy.Network;
using VeloBrawl.Service.Laser;
using VeloBrawl.Titan.Graphic;
using VeloBrawl.Tools.LaserData;

namespace VeloBrawl.Manage.Laser;

public class Loader
{
    private const int MinPort = 1024;
    private const int MaxPort = 65535;

    private List<int> _tcpPorts = [];
    private string _udpHost = null!;
    private List<int> _udpPorts = [];

    public void LoadNet()
    {
        Business.HttpLaserSocketListener = new HttpLaserSocketListener("127.0.0.1", 9119);
        Business.ProxySocketTransportListener = new ProxySocketTransportListener("0.0.0.0:10001");
        ProxyStaticalClient.ProxySocketTransportClient = new ProxySocketTransportClient("localhost:10002");

        foreach (var data in _tcpPorts)
            Business.TcpLaserSocketListeners.Add(data, new TcpLaserSocketListener($"0.0.0.0:{data}", true));

        foreach (var data in _udpPorts)
            Business.UdpLaserSocketListeners.Add(data, new UdpLaserSocketListener(data));
    }

    public void ManageNet()
    {
        try { Business.HttpLaserSocketListener!.StartSocket(); }
        catch (Exception ex)
        {
            ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Warn,
                $"HTTP listener failed (non-critical): {ex.Message}");
        }

        try { Business.ProxySocketTransportListener!.StartSocket(); }
        catch (Exception ex)
        {
            ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Warn,
                $"Proxy transport failed (non-critical): {ex.Message}");
        }

        foreach (var data in _tcpPorts)
        {
            if (!Business.TcpLaserSocketListeners.ContainsKey(data)) continue;
            try { Business.TcpLaserSocketListeners[data]!.StartSocket(); }
            catch (Exception ex)
            {
                ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Error,
                    $"TCP port {data} failed: {ex.Message}");
                throw;
            }
        }

        foreach (var data in _udpPorts)
        {
            if (!Business.UdpLaserSocketListeners.ContainsKey(data)) continue;
            try { Business.UdpLaserSocketListeners[data]!.StartSocket(); }
            catch (Exception ex)
            {
                ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Error,
                    $"UDP port {data} failed: {ex.Message}");
                throw;
            }
        }

        Saver.UdpInfoDomain = _udpHost;
        Saver.UdpInfoPorts = _udpPorts;
        Saver.TcpInfoPorts = _tcpPorts;

        Saver.TcpLaserSocketListeners = Business.TcpLaserSocketListeners;
        Saver.UdpLaserSocketListeners = Business.UdpLaserSocketListeners;

        try { ProxyStaticalClient.ProxySocketTransportClient.StartTransportClient(); }
        catch (Exception ex)
        {
            ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Warn,
                $"Proxy client failed (non-critical): {ex.Message}");
        }
    }

    public void ManageDb()
    {
        Databases.AccountDatabase.LoadDataFromFile();
        Databases.AccountDatabase.CyclingLoadDataFromFile(30);

        Databases.AllianceDatabase.LoadDataFromFile();
        Databases.AllianceDatabase.CyclingLoadDataFromFile(30);

        Databases.NotificationIntraSignedDatabase.Debug();
    }

    public void ManageTools()
    {
        Fingerprint.Parse();
    }

    public void SetParameters(string udpHost, List<int> udpInfoPorts, List<int> tcpInfoPorts)
    {
        _udpHost = udpHost;
        _udpPorts = udpInfoPorts.Where(p => p >= MinPort && p <= MaxPort).ToList();
        _tcpPorts = tcpInfoPorts.Where(p => p >= MinPort && p <= MaxPort).ToList();
    }
}