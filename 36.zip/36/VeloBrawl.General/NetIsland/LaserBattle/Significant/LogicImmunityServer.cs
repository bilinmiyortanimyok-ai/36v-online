namespace VeloBrawl.General.NetIsland.LaserBattle.Significant;

public class LogicImmunityServer
{
    public int TargetIndex;
    public int Ticks;

    public LogicImmunityServer(int targetIndex, int ticks)
    {
        TargetIndex = targetIndex;
        Ticks       = ticks;
    }

    public bool Tick(int delta = 1)
    {
        Ticks -= delta;
        return Ticks < 1;
    }

    public bool IsImmuneTo(int targetIndex) => TargetIndex == targetIndex;
}
