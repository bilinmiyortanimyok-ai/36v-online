using VeloBrawl.Tools.LaserCsv.Manufacturer.Laser;

namespace VeloBrawl.General.NetIsland.LaserBattle.Significant.Attack;

public class LogicAttackSpecialParams
{
    public LogicAreaEffectData? AreaEffectData;

    public int Stun;
    public int WeakStun;
    public int BounceHeal;
    public int StealBulletPercent;
    public int StealBulletPercentSelf;
    public int DamageDebuff;
    public int DamageBuff;
    public int StaticPercentDamage;
    public int MinPercentDamage;
    public int Pushback;
    public int TrailAreaInterval;
    public string? TrailArea;
    public int HealOthers;
    public int DotAoe;

    public int SpeedBuffModifier;
    public int SpeedBuffLength;

    public int SpawnHealth;
    public int SpawnDamage;
    public string? SummonedCharacter;
    public int MaxSpawns;

    public bool HasStun     => Stun > 0;
    public bool HasPushback => Pushback != 0;
    public bool HasDamageBuff => DamageBuff != 0;
    public bool HasDamageDebuff => DamageDebuff != 0;
    public bool HasSpeedBuff => SpeedBuffModifier != 0 && SpeedBuffLength > 0;
}
