using VeloBrawl.General.NetIsland.LaserBattle.Objects;
using VeloBrawl.General.NetIsland.LaserBattle.Objects.Laser;
using VeloBrawl.General.NetIsland.LaserBattle.Render.Tile;
using VeloBrawl.Titan.Mathematical;
using VeloBrawl.Titan.Utilities;
using VeloBrawl.Tools.LaserCsv;

namespace VeloBrawl.General.NetIsland.LaserBattle.Significant;

public class LogicPetrolServer(int a1)
{
    public int PetrolType       { get; set; } = a1;
    public int PetrolTileX      { get; private set; }
    public int PetrolTileY      { get; private set; }
    public int OwnerPlayerIndex { get; set; } = -1;

    private bool _ignited;
    private int  _destructTicks;
    private int  _slowPercent = 30;

    public void Tick(LogicBattleModeServer logicBattleModeServer)
    {
        if (PetrolType == 0) return;

        var centerX = PetrolTileX * 300 + 150;
        var centerY = PetrolTileY * 300 + 150;

        foreach (var obj in logicBattleModeServer.GameObjectManager.GetNumGameObjects())
        {
            if (obj is not LogicCharacterServer hero) continue;
            if (!hero.GetCharacterData().IsHero()) continue;
            var player = hero.GetPlayer();
            if (player == null) continue;
            if (player.GetPlayerIndex() / 16 == OwnerPlayerIndex / 16) continue;

            var dist = LogicGamePlayUtil.GetDistanceBetween(hero.GetX(), hero.GetY(), centerX, centerY);
            if (dist >= hero.GetCharacterData().GetCollisionRadius() + 150) continue;

            hero.AddBuff(new LogicBuffServer(
                (int)LogicBuffServer.BuffType.SpeedSlower, 2,
                -hero.GetCharacterData().GetSpeed() * _slowPercent / 100, 0));
        }

        if (_destructTicks > 0)
        {
            _destructTicks--;
            if (_destructTicks == 0) PetrolType = 0;
        }
    }

    public void Ignite(LogicGameObjectServer source, int logicX, int logicY, int ownerPlayerIndex)
    {
        var areaEffectData = LogicDataTables.GetAreaEffectByName("PetrolDistributionArea");

        PetrolType       = 1;
        PetrolTileX      = LogicTileMap.LogicToTile(logicX);
        PetrolTileY      = LogicTileMap.LogicToTile(logicY);
        OwnerPlayerIndex = ownerPlayerIndex;

        var areaEffect = new LogicAreaEffectServer(
            source.GetLogicBattleModeServer(),
            areaEffectData.GetClassId(), areaEffectData.GetInstanceId(),
            source.GetIndex());
        areaEffect.SetPosition(logicX, logicY, 0);
        source.GetLogicGameObjectManager().AddLogicGameObject(areaEffect);
    }

    public void IgniteFire(LogicGameObjectServer source, int damage)
    {
        if (_ignited) return;
        _ignited = true;

        var fireData = LogicDataTables.GetAreaEffectByName("PetrolFire");
        var fire = new LogicAreaEffectServer(
            source.GetLogicBattleModeServer(),
            fireData.GetClassId(), fireData.GetInstanceId(),
            source.GetIndex());
        fire.SetPosition(PetrolTileX * 300 + 150, PetrolTileY * 300 + 150, 0);
        source.GetLogicGameObjectManager().AddLogicGameObject(fire);

        _destructTicks = 4;
        PetrolType = 2;
    }
}
