namespace VeloBrawl.General.NetIsland.LaserBattle.Significant;

public class LogicBuffServer
{
    public enum BuffType
    {
        Damage      = 1,
        DamageSize  = 2,
        SpeedSlower = 3,
        SpeedFaster = 4,
        Damage2     = 5,
        HealthRegen = 10,
        BelleWeapon = 14,
        BelleUlti   = 15,
        RuffsBuff   = 13,
    }

    public int Type;
    public int Duration;
    public int DurationMax;
    public int Modifier;
    public int SizeIncrease;
    public int SourceIndex;
    public int EffectType;
    public int NormalDmg;

    public LogicBuffServer(int type, int duration, int modifier, int sizeIncrease)
    {
        Type        = type;
        Duration    = duration;
        DurationMax = duration;
        Modifier    = modifier;
        SizeIncrease = sizeIncrease;
    }

    public bool CanStack() => Type == (int)BuffType.HealthRegen;

    public bool Tick()
    {
        Duration--;
        return Duration < 1;
    }

    public int GetSpeedModifier()
    {
        return Type is (int)BuffType.SpeedSlower or (int)BuffType.SpeedFaster ? Modifier : 0;
    }

    public int GetDamageModifier()
    {
        return Type is (int)BuffType.Damage or (int)BuffType.Damage2 or (int)BuffType.DamageSize ? Modifier : 0;
    }
}
