using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;
using VeloBrawl.Titan.Mathematical.Data;
using VeloBrawl.Logic.Database.Account;
using VeloBrawl.Supercell.Titan.CommonUtils.Utils;
using VeloBrawl.Titan.DataStream.Helps;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicSetPlayerThumbnailCommand : LogicCommand
    {
        public int ThumbnailData;
        public int ThumbnailInstanceId;

        public override void Encode(ByteStream byteStream)
        {
            base.Encode(byteStream);
            byteStream.WriteVInt(ThumbnailData);
        }

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            ThumbnailData       = ByteStreamHelper.ReadDataReference(byteStream);
            ThumbnailInstanceId = GlobalId.GetInstanceId(ThumbnailData);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            if (ThumbnailInstanceId < 0) return -1;
        
            int globalId = GlobalId.CreateGlobalId(CsvHelperTable.PlayerThumbnails.GetId(), ThumbnailInstanceId);
            logicHomeMode.Home.ThumbnailId = globalId;
            logicHomeMode.AccountModel.SetFieldValueByAccountStructureParameterFromAccountModel(
                AccountStructure.PlayerThumbnailGlobalId, globalId);
            return 0;
        }
        
        public override bool CanExecute(LogicHomeMode logicHomeMode) => true;

        public override int GetCommandType()
        {
            return 505;
        }
    }
