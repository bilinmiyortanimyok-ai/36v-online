using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class ScoreChange
    {
        public int Value;       // offset +0  (a1+0)
        public int ItemData;    // offset +8  (a1+8) — DataReference

        public void Encode(ByteStream byteStream)
        {
            byteStream.WriteVInt(Value);
            byteStream.WriteVInt(ItemData);
        }

        public void Decode(ByteStream byteStream)
        {
            Value = byteStream.ReadVInt();
            ItemData = byteStream.ReadVInt();
        }
    }

    public class LogicDecreaseHeroScoreCommand : LogicCommand
    {
        public int HeroGlobalId;        // offset +48 — ReadInt (vtable+216)
        public List<ScoreChange> ScoreChanges = new List<ScoreChange>();

        public override void Encode(ByteStream byteStream)
        {
            byteStream.WriteInt(HeroGlobalId);
            byteStream.WriteVInt(ScoreChanges.Count);
            foreach (var sc in ScoreChanges)
                sc.Encode(byteStream);
            base.Encode(byteStream);
        }

        public override void Decode(ByteStream byteStream)
        {
            HeroGlobalId = byteStream.ReadInt();
            int count = byteStream.ReadVInt();
            for (int i = 0; i < count; i++)
            {
                var sc = new ScoreChange();
                sc.Decode(byteStream);
                ScoreChanges.Add(sc);
            }
            base.Decode(byteStream);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 205;
        }
    }
