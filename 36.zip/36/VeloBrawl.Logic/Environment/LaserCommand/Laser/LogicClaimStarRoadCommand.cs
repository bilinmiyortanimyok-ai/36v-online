using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

public class LogicClaimStarRoadCommand : LogicCommand
{
    private int _brawlerId;

    public override void Decode(ByteStream byteStream)
    {
        base.Decode(byteStream);
        byteStream.ReadVInt();
        _brawlerId = byteStream.ReadVInt();
    }

    public override void Encode(ByteStream byteStream)
    {
        base.Encode(byteStream);
        byteStream.WriteVInt(0);
        byteStream.WriteVInt(_brawlerId);
    }

    public override bool CanExecute(LogicHomeMode logicHomeMode) => true;
    public override int Execute(LogicHomeMode logicHomeMode) => 0;
    public override int GetCommandType() => 562;
}
