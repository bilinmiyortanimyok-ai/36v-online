using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicViewInboxNotificationCommand : LogicCommand
    {
        public int NotificationIndex;
        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            NotificationIndex = byteStream.ReadVInt();
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 528;
        }
    }
