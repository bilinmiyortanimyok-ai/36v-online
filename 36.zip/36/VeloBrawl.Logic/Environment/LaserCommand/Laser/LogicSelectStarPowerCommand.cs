using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicSelectStarPowerCommand : LogicCommand
    {
        public int StarpowerInstanceId;

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            byteStream.ReadVInt();
            StarpowerInstanceId = byteStream.ReadVInt();
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 529;
        }
    }
