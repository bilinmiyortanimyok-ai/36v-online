using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicUnlockSkinCommand : LogicCommand
    {
        public int SkinData;

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            SkinData = byteStream.ReadVInt();
        }

        public override void Encode(ByteStream byteStream)
        {
            base.Encode(byteStream);
            byteStream.WriteVInt(SkinData);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 507;
        }
    }
