using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicVideoStartedCommand : LogicCommand
    {
        public int VideoType;

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            VideoType = byteStream.ReadVInt();
        }

        public override void Encode(ByteStream byteStream)
        {
            base.Encode(byteStream);
            byteStream.WriteVInt(VideoType);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 524;
        }
    }
