using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicProLeagueSeasonChangedCommand : LogicCommand
    {
        public int Season;
        public int EndTimestamp;

        public override void Encode(ByteStream byteStream)
        {
            byteStream.WriteVInt(Season);
            byteStream.WriteVInt(EndTimestamp);
            base.Encode(byteStream);
        }

        public override void Decode(ByteStream byteStream)
        {
            Season = byteStream.ReadVInt();
            EndTimestamp = byteStream.ReadVInt();
            base.Decode(byteStream);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 217;
        }
    }
