using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicSendAllianceMailCommand : LogicCommand
    {
        public string Subject = string.Empty;
        public string Body    = string.Empty;

        public override void Encode(ByteStream byteStream)
        {
            byteStream.WriteString(Subject);
            byteStream.WriteString(Body);
            base.Encode(byteStream);
        }

        public override void Decode(ByteStream byteStream)
        {
            Subject = byteStream.ReadString(900000);
            Body    = byteStream.ReadString(900000);
            base.Decode(byteStream);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 504;
        }
    }
