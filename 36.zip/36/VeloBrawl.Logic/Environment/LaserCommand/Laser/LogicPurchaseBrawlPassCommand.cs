using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicPurchaseBrawlPassCommand : LogicCommand
    {
        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            byteStream.ReadVInt();
            byteStream.ReadBoolean();
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            if (logicHomeMode.Avatar.UseDiamonds(169))
            {
                logicHomeMode.Home.HasPremiumPass = true;
                return 0;
            }

            return -1;
        }

        public override int GetCommandType()
        {
            return 534;
        }
    }
