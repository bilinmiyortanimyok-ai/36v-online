using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

public class LogicEditBattlePassCommand : LogicCommand
{
    private int _characterId;
    private int _vanityId;
    private bool _unk1;
    private int _index;

    public override void Decode(ByteStream byteStream)
    {
        base.Decode(byteStream);
        _characterId = byteStream.ReadVInt();
        byteStream.ReadVInt();
        _vanityId = byteStream.ReadVInt();
        byteStream.ReadVInt();
        _unk1 = byteStream.ReadBoolean();
        _index = byteStream.ReadVInt();
    }

    public override void Encode(ByteStream byteStream)
    {
        base.Encode(byteStream);
        byteStream.WriteVInt(_characterId);
        byteStream.WriteVInt(0);
        byteStream.WriteVInt(_vanityId);
        byteStream.WriteVInt(0);
        byteStream.WriteBoolean(_unk1);
        byteStream.WriteVInt(_index);
    }

    public override bool CanExecute(LogicHomeMode logicHomeMode) => true;
    public override int Execute(LogicHomeMode logicHomeMode) => 0;
    public override int GetCommandType() => 568;
}
