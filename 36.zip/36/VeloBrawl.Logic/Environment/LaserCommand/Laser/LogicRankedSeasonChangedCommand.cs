using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicRankedSeasonChangedCommand : LogicCommand
    {
        public bool HasSeasonData;

        public override void Encode(ByteStream byteStream)
        {
            base.Encode(byteStream);
            byteStream.WriteBoolean(HasSeasonData);
            // LogicPlayerRankedSeasonData.Encode() goes here when implemented
        }

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            HasSeasonData = byteStream.ReadBoolean();
            // LogicPlayerRankedSeasonData.Decode() goes here when implemented
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 222;
        }
    }
