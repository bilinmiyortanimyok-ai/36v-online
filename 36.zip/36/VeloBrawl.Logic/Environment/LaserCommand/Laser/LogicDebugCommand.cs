using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicDebugCommand : LogicCommand
    {
        public int DebugType;       // offset +28
        public int DebugParam;      // offset +32
        public string Message = string.Empty; // offset +40
        public int DataRef1;        // offset +56
        public int DataRef2;        // offset +64

        public override void Encode(ByteStream byteStream)
        {
            base.Encode(byteStream);
            byteStream.WriteVInt(DebugType);
            byteStream.WriteVInt(DebugParam);
            byteStream.WriteString(Message);
            byteStream.WriteVInt(DataRef1);
            byteStream.WriteVInt(DataRef2);
        }

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            DebugType  = byteStream.ReadVInt();
            DebugParam = byteStream.ReadVInt();
            Message    = byteStream.ReadString(900000);
            DataRef1   = byteStream.ReadVInt();
            DataRef2   = byteStream.ReadVInt();
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 1000;
        }
    }
