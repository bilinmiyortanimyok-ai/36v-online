using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicGemNameChangeStateChangedCommand : LogicCommand
    {
        public int State;
        public int CooldownSecs;

        public override void Encode(ByteStream byteStream)
        {
            byteStream.WriteVInt(State);
            byteStream.WriteVInt(CooldownSecs);
            base.Encode(byteStream);
        }

        public override void Decode(ByteStream byteStream)
        {
            State = byteStream.ReadVInt();
            CooldownSecs = byteStream.ReadVInt();
            base.Decode(byteStream);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 214;
        }
    }
