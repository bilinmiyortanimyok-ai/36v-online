using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicCooldownExpiredCommand : LogicCommand
    {
        public int CooldownType;
        public int ItemData;

        public override void Encode(ByteStream byteStream)
        {
            byteStream.WriteVInt(CooldownType);
            byteStream.WriteVInt(ItemData);
            base.Encode(byteStream);
        }

        public override void Decode(ByteStream byteStream)
        {
            CooldownType = byteStream.ReadVInt();
            ItemData = byteStream.ReadVInt();
            base.Decode(byteStream);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 216;
        }
    }
