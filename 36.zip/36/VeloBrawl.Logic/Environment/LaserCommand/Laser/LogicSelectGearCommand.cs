using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

public class LogicSelectGearCommand : LogicCommand
{
    private int _characterId;
    private int _gearId;
    private int _gearSlot;

    public override void Decode(ByteStream byteStream)
    {
        base.Decode(byteStream);
        byteStream.ReadVInt();
        _characterId = byteStream.ReadVInt();
        byteStream.ReadVInt();
        _gearId = byteStream.ReadVInt();
        _gearSlot = byteStream.ReadVInt();
    }

    public override void Encode(ByteStream byteStream)
    {
        base.Encode(byteStream);
        byteStream.WriteVInt(0);
        byteStream.WriteVInt(_characterId);
        byteStream.WriteVInt(0);
        byteStream.WriteVInt(_gearId);
        byteStream.WriteVInt(_gearSlot);
    }

    public override bool CanExecute(LogicHomeMode logicHomeMode) => true;
    public override int Execute(LogicHomeMode logicHomeMode) => 0;
    public override int GetCommandType() => 543;
}
