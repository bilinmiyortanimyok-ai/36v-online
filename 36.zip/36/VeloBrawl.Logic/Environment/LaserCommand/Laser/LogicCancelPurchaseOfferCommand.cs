using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicCancelPurchaseOfferCommand : LogicCommand
    {
        public int OfferId;
        public int OfferSlot;

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            OfferId = byteStream.ReadVInt();
            OfferSlot = byteStream.ReadVInt();
        }

        public override void Encode(ByteStream byteStream)
        {
            base.Encode(byteStream);
            byteStream.WriteVInt(OfferId);
            byteStream.WriteVInt(OfferSlot);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 531;
        }
    }
