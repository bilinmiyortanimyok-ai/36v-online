using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicChangeControlModeCommand : LogicCommand
    {
        public int ControlMode;

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            ControlMode = byteStream.ReadVInt();
        }

        public override void Encode(ByteStream byteStream)
        {
            base.Encode(byteStream);
            byteStream.WriteVInt(ControlMode);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 508;
        }
    }
