using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

public class LogicEditBattlePassCommand1 : LogicCommand
{
    private bool _unk1;

    public override void Decode(ByteStream byteStream)
    {
        base.Decode(byteStream);
        _unk1 = byteStream.ReadBoolean();
    }

    public override void Encode(ByteStream byteStream)
    {
        base.Encode(byteStream);
        byteStream.WriteBoolean(_unk1);
    }

    public override bool CanExecute(LogicHomeMode logicHomeMode) => true;
    public override int Execute(LogicHomeMode logicHomeMode) => 0;
    public override int GetCommandType() => 567;
}
