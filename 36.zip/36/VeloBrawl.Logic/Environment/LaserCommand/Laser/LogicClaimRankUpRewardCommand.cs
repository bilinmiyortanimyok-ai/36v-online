using System.Numerics;
using VeloBrawl.Logic.Environment.LaserListener;
using VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_9;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Logic.Database;
using VeloBrawl.Titan.DataStream;
using VeloBrawl.Tools.LaserCsv;
using VeloBrawl.Tools.LaserCsv.Manufacturer.Laser;
using VeloBrawl.Titan.Mathematical.Data;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

public class LogicClaimRankUpRewardCommand : LogicCommand
{
    public int MilestoneId { get; set; }
    public int UnknownDataId { get; set; }
    public int Unk2 { get; set; }
    public int Unk3 { get; set; }
    public int RequieredMilestone { get; set; }

    private static bool BitGet(BigInteger value, int index) =>
        ((value >> index) & BigInteger.One) == BigInteger.One;

    private static BigInteger BitSet(BigInteger value, int index) =>
        value | (BigInteger.One << index);

    public override void Decode(ByteStream byteStream)
    {
        base.Decode(byteStream);
        MilestoneId        = byteStream.ReadVInt();
        UnknownDataId      = byteStream.ReadVInt();
        Unk2               = byteStream.ReadVInt();
        RequieredMilestone = byteStream.ReadVInt();
    }

    public override bool CanExecute(LogicHomeMode logicHomeMode)
    {
        if (MilestoneId == 9 && !logicHomeMode.Home.HasPremiumPass) return false;
        return true;
    }

    public override int Execute(LogicHomeMode logicHomeMode)
    {
        var gameListener = logicHomeMode.GameListener;

        if (MilestoneId == 6)
        {
            string name = $"goal_6_{logicHomeMode.Home.TrophyRoadProgress - 1}";
            LogicMilestoneData? milestoneData = LogicDataTables.GetMilestoneByName(name);
            if (milestoneData == null) return -111;

            if (logicHomeMode.Avatar.HighestTrophies < milestoneData.GetProgress() + milestoneData.GetProgressStart())
                return -2;

            if (ProcessReward(gameListener, logicHomeMode, milestoneData, false, 6, logicHomeMode.Home.TrophyRoadProgress + 1, false) != 0) return -3;

            logicHomeMode.Home.TrophyRoadProgress++;
            Databases.AccountDatabase.OnAssistByAccountInFile(logicHomeMode.AccountModel, true, logicHomeMode.AccountModel.GetAccountId());
        }
        else if (MilestoneId == 9 || MilestoneId == 10)
        {
            if (MilestoneId == 9 && !logicHomeMode.Home.HasPremiumPass) return -5;

            var mask = MilestoneId == 9
                ? logicHomeMode.Home.PremiumPassProgress
                : logicHomeMode.Home.BrawlPassProgress;

            int bitIndex = RequieredMilestone;

            if (BitGet(mask, bitIndex)) return 0;

            string name = $"Goal_{MilestoneId}_6_{RequieredMilestone}";
            LogicMilestoneData? milestoneData = LogicDataTables.GetMilestoneByName(name);
            if (milestoneData == null) return -111;

            if (logicHomeMode.Home.BrawlPassTokens < milestoneData.GetProgress() + milestoneData.GetProgressStart())
                return -2;

            if (ProcessReward(gameListener, logicHomeMode, milestoneData, false, MilestoneId, RequieredMilestone + 1, false) != 0) return -3;

            if (MilestoneId == 9)
                logicHomeMode.Home.PremiumPassProgress = (int)BitSet(mask, bitIndex);
            else
                logicHomeMode.Home.BrawlPassProgress = (int)BitSet(mask, bitIndex);

            Databases.AccountDatabase.OnAssistByAccountInFile(logicHomeMode.AccountModel, true, logicHomeMode.AccountModel.GetAccountId());
        }
        else
        {
            return -1;
        }

        return 0;
    }

    private int ProcessReward(LogicGameListener? gameListener, LogicHomeMode logicHomeMode, LogicMilestoneData milestoneData, bool useSecondary, int track, int idx, bool isBp)
    {
        int type    = useSecondary ? milestoneData.GetSecondaryLvlUpRewardType() : milestoneData.GetPrimaryLvlUpRewardType();
        string data = useSecondary ? milestoneData.GetSecondaryLvlUpRewardData() : milestoneData.GetPrimaryLvlUpRewardData();
        int count   = useSecondary ? milestoneData.GetSecondaryLvlUpRewardCount() : milestoneData.GetPrimaryLvlUpRewardCount();

        void SendCommand(LogicGiveDeliveryItemsCommand cmd)
        {
            cmd.RewardTrackType = track;
            cmd.RewardForRank   = idx;
            if (isBp) cmd.BrawlPassSeason = 1;
            var msg = new AvailableServerCommandMessage();
            msg.SetServerCommand(cmd);
            gameListener?.Send(msg);
        }

        switch (type)
        {
            case 1:
            {
                var cmd  = new LogicGiveDeliveryItemsCommand();
                var unit = new DeliveryUnit(100);
                unit.AddDrop(new GatchaDrop(7) { Count = count });
                cmd.DeliveryUnits.Add(unit);
                SendCommand(cmd);
                break;
            }
            case 3:
            {
                var charData = LogicDataTables.GetCharacterByName(data);
                if (charData == null) return ProcessReward(gameListener, logicHomeMode, milestoneData, true, track, idx, isBp);
                if (logicHomeMode.Avatar.HasHero(charData.GetGlobalId()))
                    return ProcessReward(gameListener, logicHomeMode, milestoneData, true, track, idx, isBp);

                var cmd  = new LogicGiveDeliveryItemsCommand();
                var unit = new DeliveryUnit(100);
                unit.AddDrop(new GatchaDrop(1) { DataGlobalId = charData.GetGlobalId(), Count = 1 });
                cmd.DeliveryUnits.Add(unit);
                SendCommand(cmd);
                break;
            }
            case 6:
            {
                var cmd  = new LogicGiveDeliveryItemsCommand();
                var unit = new DeliveryUnit(10);
                logicHomeMode.SimulateGatcha(unit);
                cmd.DeliveryUnits.Add(unit);
                SendCommand(cmd);
                break;
            }
            case 9:
            {
                var cmd  = new LogicGiveDeliveryItemsCommand();
                var unit = new DeliveryUnit(100);
                unit.AddDrop(new GatchaDrop(2) { Count = count });
                cmd.DeliveryUnits.Add(unit);
                SendCommand(cmd);
                break;
            }
            case 4:
            case 24:
            {
                var skinData = LogicDataTables.GetSkinByName(data);
                if (skinData == null) return -3;
                var skinConfData = LogicDataTables.GetSkinConfByName(skinData.GetConf());
                var cmd  = new LogicGiveDeliveryItemsCommand();
                var unit = new DeliveryUnit(100);
                var charData2 = LogicDataTables.GetCharacterByName(skinConfData.GetCharacter());
                if (charData2 != null && !logicHomeMode.Avatar.HasHero(charData2.GetGlobalId()))
                    unit.AddDrop(new GatchaDrop(1) { DataGlobalId = charData2.GetGlobalId(), Count = 1 });
                unit.AddDrop(new GatchaDrop(9) { SkinGlobalId = skinData.GetGlobalId(), Count = 1 });
                cmd.DeliveryUnits.Add(unit);
                SendCommand(cmd);
                break;
            }
            case 10:
            {
                var cmd  = new LogicGiveDeliveryItemsCommand();
                var unit = new DeliveryUnit(11);
                logicHomeMode.SimulateGatcha(unit);
                cmd.DeliveryUnits.Add(unit);
                SendCommand(cmd);
                break;
            }
            case 12:
            {
                if (UnknownDataId < GlobalId.CreateGlobalId(16, 0)) return ProcessReward(gameListener, logicHomeMode, milestoneData, true, track, idx, isBp);
                var charData3 = LogicDataTables.GetDataByGlobalId<LogicCharacterData>(16, UnknownDataId);
                if (charData3 == null) return ProcessReward(gameListener, logicHomeMode, milestoneData, true, track, idx, isBp);

                var cmd  = new LogicGiveDeliveryItemsCommand();
                var unit = new DeliveryUnit(100);
                unit.AddDrop(new GatchaDrop(6) { DataGlobalId = charData3.GetGlobalId(), Count = count });
                cmd.DeliveryUnits.Add(unit);
                SendCommand(cmd);
                break;
            }
            case 13:
                break;
            case 14:
            {
                var cmd  = new LogicGiveDeliveryItemsCommand();
                var unit = new DeliveryUnit(12);
                logicHomeMode.SimulateGatcha(unit);
                cmd.DeliveryUnits.Add(unit);
                SendCommand(cmd);
                break;
            }
            case 16:
            {
                var cmd  = new LogicGiveDeliveryItemsCommand();
                var unit = new DeliveryUnit(100);
                unit.AddDrop(new GatchaDrop(8) { Count = count });
                cmd.DeliveryUnits.Add(unit);
                SendCommand(cmd);
                break;
            }
            case 18:
            {
                logicHomeMode.Home.Quests = new Quests();
                logicHomeMode.Home.Quests.AddRandomQuests(logicHomeMode.Avatar.Heroes, 8);

                var cmd = new LogicHeroWinQuestsChangedCommand { Quests = logicHomeMode.Home.Quests };
                var msg = new AvailableServerCommandMessage();
                msg.SetServerCommand(cmd);
                gameListener?.Send(msg);
                break;
            }
            case 19:
            {
                var emoteData = LogicDataTables.GetDataFromTable(52)?.GetDataByName(data);
                if (emoteData == null) break;
                var cmd  = new LogicGiveDeliveryItemsCommand();
                var unit = new DeliveryUnit(100);
                unit.AddDrop(new GatchaDrop(11) { PinGlobalId = emoteData.GetGlobalId(), Count = 1 });
                logicHomeMode.Home.UnlockedEmotes.Add(emoteData.GetGlobalId() - 52000000);
                cmd.DeliveryUnits.Add(unit);
                SendCommand(cmd);
                break;
            }
            case 21:
            {
                var allEmotes = Enumerable.Range(0, 31).ToList();
                var locked    = allEmotes.Except(logicHomeMode.Home.UnlockedEmotes).OrderBy(_ => Guid.NewGuid()).Take(3).ToList();
                var cmd  = new LogicGiveDeliveryItemsCommand();
                var unit = new DeliveryUnit(100);
                foreach (int x in locked)
                {
                    unit.AddDrop(new GatchaDrop(11) { PinGlobalId = 52000000 + x, Count = 1 });
                    logicHomeMode.Home.UnlockedEmotes.Add(x);
                }
                cmd.DeliveryUnits.Add(unit);
                SendCommand(cmd);
                break;
            }
            default:
                return -3;
        }

        return 0;
    }

    public override int GetCommandType() => 517;
}