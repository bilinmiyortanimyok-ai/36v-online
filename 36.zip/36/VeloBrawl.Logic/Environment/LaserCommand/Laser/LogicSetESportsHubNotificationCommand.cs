using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicSetESportsHubNotificationCommand : LogicCommand
    {
        public int NotificationId;

        public override void Encode(ByteStream byteStream)
        {
            byteStream.WriteInt(NotificationId);
            base.Encode(byteStream);
        }

        public override void Decode(ByteStream byteStream)
        {
            NotificationId = byteStream.ReadInt();
            base.Decode(byteStream);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 224;
        }
    }
