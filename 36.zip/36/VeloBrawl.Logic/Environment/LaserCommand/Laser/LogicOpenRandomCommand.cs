using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

public class LogicOpenRandomCommand : LogicCommand
{
    public override void Decode(ByteStream byteStream)
    {
    }

    public override bool CanExecute(LogicHomeMode logicHomeMode) => true;
    public override int Execute(LogicHomeMode logicHomeMode) => 0;
    public override int GetCommandType() => 571;
}
