using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicVanityItemSeenCommand : LogicCommand
    {
        public int VanityItemData;

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            VanityItemData = byteStream.ReadVInt();
        }

        public override void Encode(ByteStream byteStream)
        {
            base.Encode(byteStream);
            byteStream.WriteVInt(VanityItemData);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 537;
        }
    }
