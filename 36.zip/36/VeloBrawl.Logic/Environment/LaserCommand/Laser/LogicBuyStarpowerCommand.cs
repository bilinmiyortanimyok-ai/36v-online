using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

public class LogicBuyStarpowerCommand : LogicCommand
{
    private int _id;

    public override void Decode(ByteStream byteStream)
    {
        base.Decode(byteStream);
        _id = byteStream.ReadVInt();
        byteStream.ReadVInt();
    }

    public override void Encode(ByteStream byteStream)
    {
        base.Encode(byteStream);
        byteStream.WriteVInt(_id);
        byteStream.WriteVInt(0);
    }

    public override bool CanExecute(LogicHomeMode logicHomeMode) => true;

    public override int Execute(LogicHomeMode logicHomeMode)
    {
        return 0;
    }

    public override int GetCommandType() => 557;
}
