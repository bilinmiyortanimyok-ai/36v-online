using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicPurchaseChallengeLivesCommand : LogicCommand
    {
        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
        }

        public override void Encode(ByteStream byteStream)
        {
            base.Encode(byteStream);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 540;
        }
    }
