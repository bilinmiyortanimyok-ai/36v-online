using VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_9;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicGatchaCommand : LogicCommand
    {
        public int BoxIndex;

        public LogicGatchaCommand() : base()
        {
            ;
        }

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            BoxIndex = byteStream.ReadVInt();
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            if (BoxIndex == 3)
            {
                if (!logicHomeMode.Avatar.UseDiamonds(80)) return -1;

                LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();
                DeliveryUnit unit = new DeliveryUnit(11);
                logicHomeMode.SimulateGatcha(unit);
                command.DeliveryUnits.Add(unit);
                command.Execute(logicHomeMode);

                AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                message.SetServerCommand(command);
                logicHomeMode.GameListener.Send(message);
            }
            else if (BoxIndex == 1)
            {
                if (!logicHomeMode.Avatar.UseDiamonds(30)) return -1;

                LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();
                DeliveryUnit unit = new DeliveryUnit(12);
                logicHomeMode.SimulateGatcha(unit);
                command.DeliveryUnits.Add(unit);
                command.Execute(logicHomeMode);

                AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                message.SetServerCommand(command);
                logicHomeMode.GameListener.Send(message);
            }
            else if (BoxIndex == 4)
            {
                if (!logicHomeMode.Avatar.UseStarTokens(10)) return -1;

                LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();
                DeliveryUnit unit = new DeliveryUnit(12);
                logicHomeMode.SimulateGatcha(unit);
                command.DeliveryUnits.Add(unit);
                command.Execute(logicHomeMode);

                AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                message.SetServerCommand(command);
                logicHomeMode.GameListener.Send(message);
            }
            else if (BoxIndex == 5)
            {
                if (!logicHomeMode.Avatar.UseTokens(100)) return -1;

                LogicGiveDeliveryItemsCommand command = new LogicGiveDeliveryItemsCommand();
                DeliveryUnit unit = new DeliveryUnit(10);
                logicHomeMode.SimulateGatcha(unit);
                command.DeliveryUnits.Add(unit);
                command.Execute(logicHomeMode);

                AvailableServerCommandMessage message = new AvailableServerCommandMessage();
                message.SetServerCommand(command);
                logicHomeMode.GameListener.Send(message);
            }
            else
            {
                Console.WriteLine("Gatcha: Unknown box index: " + BoxIndex);
            }

            return 0;
        }

        public override bool CanExecute(LogicHomeMode logicHomeMode) => true;
        
        public override int GetCommandType()
        {
            return 500;
        }
    }
