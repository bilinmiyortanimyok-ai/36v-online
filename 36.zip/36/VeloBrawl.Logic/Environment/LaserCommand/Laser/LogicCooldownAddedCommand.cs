using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class CooldownEntry
    {
        public int ItemGlobalId;
        public int ExpiresInSecs;
        public int CooldownType;
        public int Extra;

        public void Encode(ByteStream byteStream)
        {
            byteStream.WriteVInt(ItemGlobalId);
            byteStream.WriteVInt(ExpiresInSecs);
            byteStream.WriteVInt(CooldownType);
            byteStream.WriteVInt(Extra);
        }

        public void Decode(ByteStream byteStream)
        {
            ItemGlobalId = byteStream.ReadVInt();
            ExpiresInSecs = byteStream.ReadVInt();
            CooldownType = byteStream.ReadVInt();
            Extra = byteStream.ReadVInt();
        }
    }

    public class LogicCooldownAddedCommand : LogicCommand
    {
        public List<CooldownEntry>? Entries;

        public override void Encode(ByteStream byteStream)
        {
            base.Encode(byteStream);
            if (Entries == null)
            {
                byteStream.WriteVInt(-1);
                return;
            }
            byteStream.WriteVInt(Entries.Count);
            foreach (var e in Entries)
                e.Encode(byteStream);
        }

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            int count = byteStream.ReadVInt();
            if (count < 0) return;
            Entries = new List<CooldownEntry>(count);
            for (int i = 0; i < count; i++)
            {
                var e = new CooldownEntry();
                e.Decode(byteStream);
                Entries.Add(e);
            }
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 223;
        }
    }
