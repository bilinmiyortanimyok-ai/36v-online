using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Mode;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserCommand.Laser;

    public class LogicSelectEmoteCommand : LogicCommand
    {
        public int EmoteData;
        public int SlotIndex;

        public override void Decode(ByteStream byteStream)
        {
            base.Decode(byteStream);
            EmoteData = byteStream.ReadVInt();
            SlotIndex = byteStream.ReadVInt();
        }

        public override void Encode(ByteStream byteStream)
        {
            base.Encode(byteStream);
            byteStream.WriteVInt(EmoteData);
            byteStream.WriteVInt(SlotIndex);
        }

        public override int Execute(LogicHomeMode logicHomeMode)
        {
            return 0;
        }

        public override int GetCommandType()
        {
            return 538;
        }
    }
