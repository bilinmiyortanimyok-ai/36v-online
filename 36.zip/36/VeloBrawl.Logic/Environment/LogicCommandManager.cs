using VeloBrawl.Logic.Environment.LaserCommand;
using VeloBrawl.Logic.Environment.LaserCommand.Laser;
using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment;

public abstract class LogicCommandManager
{
    private static readonly Dictionary<int, Type> CommandTypes = new()
    {
        { new LogicChangeAvatarNameCommand(string.Empty, 0).GetCommandType(), typeof(LogicChangeAvatarNameCommand) },
        { new LogicDiamondsAddedCommand().GetCommandType(), typeof(LogicDiamondsAddedCommand) },
        { new LogicDayChangedCommand(null!).GetCommandType(), typeof(LogicDayChangedCommand) },
        { new LogicDecreaseHeroScoreCommand().GetCommandType(), typeof(LogicDecreaseHeroScoreCommand) },
        { new LogicAddNotificationCommand(null!).GetCommandType(), typeof(LogicAddNotificationCommand) },
        { new LogicDeleteNotificationCommand().GetCommandType(), typeof(LogicDeleteNotificationCommand) },
        { new LogicInviteBlockingChangedCommand().GetCommandType(), typeof(LogicInviteBlockingChangedCommand) },
        { new LogicGemNameChangeStateChangedCommand().GetCommandType(), typeof(LogicGemNameChangeStateChangedCommand) },
        { new LogicSetSupportedCreatorCommand().GetCommandType(), typeof(LogicSetSupportedCreatorCommand) },
        { new LogicCooldownExpiredCommand().GetCommandType(), typeof(LogicCooldownExpiredCommand) },
        { new LogicProLeagueSeasonChangedCommand().GetCommandType(), typeof(LogicProLeagueSeasonChangedCommand) },
        { new LogicBrawlPassSeasonChangedCommand().GetCommandType(), typeof(LogicBrawlPassSeasonChangedCommand) },
        { new LogicBrawlPassUnlockedCommand().GetCommandType(), typeof(LogicBrawlPassUnlockedCommand) },
        { new LogicHeroWinQuestsChangedCommand().GetCommandType(), typeof(LogicHeroWinQuestsChangedCommand) },
        { new LogicTeamChatMuteStateChangedCommand().GetCommandType(), typeof(LogicTeamChatMuteStateChangedCommand) },
        { new LogicRankedSeasonChangedCommand().GetCommandType(), typeof(LogicRankedSeasonChangedCommand) },
        { new LogicCooldownAddedCommand().GetCommandType(), typeof(LogicCooldownAddedCommand) },
        { new LogicSetESportsHubNotificationCommand().GetCommandType(), typeof(LogicSetESportsHubNotificationCommand) },
        { new LogicGatchaCommand().GetCommandType(), typeof(LogicGatchaCommand) },
        { new LogicClaimDailyRewardCommand().GetCommandType(), typeof(LogicClaimDailyRewardCommand) },
        { new LogicSendAllianceMailCommand().GetCommandType(), typeof(LogicSendAllianceMailCommand) },
        { new LogicSetPlayerThumbnailCommand().GetCommandType(), typeof(LogicSetPlayerThumbnailCommand) },
        { new LogicSetPlayerNameColorCommand().GetCommandType(), typeof(LogicSetPlayerNameColorCommand) },
        { new LogicSelectSkinCommand().GetCommandType(), typeof(LogicSelectSkinCommand) },
        { new LogicUnlockSkinCommand().GetCommandType(), typeof(LogicUnlockSkinCommand) },
        { new LogicChangeControlModeCommand().GetCommandType(), typeof(LogicChangeControlModeCommand) },
        { new LogicPurchaseDoubleCoinsCommand().GetCommandType(), typeof(LogicPurchaseDoubleCoinsCommand) },
        { new LogicHelpOpenedCommand().GetCommandType(), typeof(LogicHelpOpenedCommand) },
        { new LogicToggleInGameHintsCommand().GetCommandType(), typeof(LogicToggleInGameHintsCommand) },
        { new LogicClearShopTickersCommand().GetCommandType(), typeof(LogicClearShopTickersCommand) },
        { new LogicClaimRankUpRewardCommand().GetCommandType(), typeof(LogicClaimRankUpRewardCommand) },
        { new LogicPurchaseOfferCommand().GetCommandType(), typeof(LogicPurchaseOfferCommand) },
        { new LogicLevelUpCommand().GetCommandType(), typeof(LogicLevelUpCommand) },
        { new LogicPurchaseHeroLvlUpMaterialCommand().GetCommandType(), typeof(LogicPurchaseHeroLvlUpMaterialCommand) },
        { new LogicHeroSeenCommand().GetCommandType(), typeof(LogicHeroSeenCommand) },
        { new LogicClaimAdRewardCommand().GetCommandType(), typeof(LogicClaimAdRewardCommand) },
        { new LogicVideoStartedCommand().GetCommandType(), typeof(LogicVideoStartedCommand) },
        { new LogicSelectCharacterCommand().GetCommandType(), typeof(LogicSelectCharacterCommand) },
        { new LogicUnlockFreeSkinsCommand().GetCommandType(), typeof(LogicUnlockFreeSkinsCommand) },
        { new LogicViewInboxNotificationCommand().GetCommandType(), typeof(LogicViewInboxNotificationCommand) },
        { new LogicSelectStarPowerCommand().GetCommandType(), typeof(LogicSelectStarPowerCommand) },
        { new LogicSetPlayerAgeCommand().GetCommandType(), typeof(LogicSetPlayerAgeCommand) },
        { new LogicCancelPurchaseOfferCommand().GetCommandType(), typeof(LogicCancelPurchaseOfferCommand) },
        { new LogicItemSeenCommand().GetCommandType(), typeof(LogicItemSeenCommand) },
        { new LogicQuestsSeenCommand().GetCommandType(), typeof(LogicQuestsSeenCommand) },
        { new LogicPurchaseBrawlPassCommand().GetCommandType(), typeof(LogicPurchaseBrawlPassCommand) },
        { new LogicClaimTailRewardCommand().GetCommandType(), typeof(LogicClaimTailRewardCommand) },
        { new LogicPurchaseBrawlPassProgressCommand().GetCommandType(), typeof(LogicPurchaseBrawlPassProgressCommand) },
        { new LogicVanityItemSeenCommand().GetCommandType(), typeof(LogicVanityItemSeenCommand) },
        { new LogicSelectEmoteCommand().GetCommandType(), typeof(LogicSelectEmoteCommand) },
        { new LogicBrawlPassAutoCollectWarningSeenCommand().GetCommandType(), typeof(LogicBrawlPassAutoCollectWarningSeenCommand) },
        { new LogicPurchaseChallengeLivesCommand().GetCommandType(), typeof(LogicPurchaseChallengeLivesCommand) },
        { new LogicClearESportsHubNotificationCommand().GetCommandType(), typeof(LogicClearESportsHubNotificationCommand) },
        { new LogicSelectGroupSkinCommand().GetCommandType(), typeof(LogicSelectGroupSkinCommand) },
        { new LogicDebugCommand().GetCommandType(), typeof(LogicDebugCommand) },
        { new LogicBuyStarpowerCommand().GetCommandType(), typeof(LogicBuyStarpowerCommand) },
        { new LogicClaimMasteriesCommand().GetCommandType(), typeof(LogicClaimMasteriesCommand) },
        { new LogicClaimStarRoadCommand().GetCommandType(), typeof(LogicClaimStarRoadCommand) },
        { new LogicOpenRandomCommand().GetCommandType(), typeof(LogicOpenRandomCommand) },
        { new LogicSelectFavouriteBrawlerCommand().GetCommandType(), typeof(LogicSelectFavouriteBrawlerCommand) },
        { new LogicSelectGearCommand().GetCommandType(), typeof(LogicSelectGearCommand) },
        { new LogicBrawlerRecruitRoadChangedCommand().GetCommandType(), typeof(LogicBrawlerRecruitRoadChangedCommand) },
        { new LogicEditBattlePassCommand().GetCommandType(), typeof(LogicEditBattlePassCommand) },
        { new LogicEditBattlePassCommand1().GetCommandType(), typeof(LogicEditBattlePassCommand1) },
    };

    public static LogicCommand? DecodeCommand(ByteStream byteStream)
    {
        LogicCommand? command = null;
        var type = byteStream.ReadVInt();

        try { command = CreateCommand(type); }
        catch { }

        if (command == null)
        {
            Console.WriteLine($"[CMD] Unknown command type: {type}");
            return null;
        }

        try
        {
            command.Decode(byteStream);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[CMD] Decode failed for type {type}: {ex.Message}");
            return null;
        }

        return command;
    }

    public static void EncodeCommand(LogicCommand logicCommand, ByteStream byteStream)
    {
        byteStream.WriteVInt(logicCommand.GetCommandType());
        logicCommand.Encode(byteStream);
    }

    public static LogicCommand? CreateCommand(int type)
    {
        if (CommandTypes.TryGetValue(type, out var commandType))
            return (LogicCommand)Activator.CreateInstance(commandType)!;

        return null;
    }
}
