using VeloBrawl.Supercell.Titan.CommonUtils;
using VeloBrawl.Titan.Mathematical;

namespace VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_9;

public class GetPlayerProfileMessage : PiranhaMessage
{
    private long _accountId;

    public GetPlayerProfileMessage()
    {
        Helper.Skip();
    }

    public override void Decode()
    {
        base.Decode();
        _accountId = ByteStream.ReadLong();
    }

    public override void Encode()
    {
        base.Encode();
        ByteStream.WriteLong(_accountId);
    }

    public long GetAccountId()
    {
        return _accountId;
    }

    public void SetAccountId(long accountId)
    {
        _accountId = accountId;
    }

    public override int GetMessageType()
    {
        return 14113;
    }

    public override int GetServiceNodeType()
    {
        return 9;
    }
}