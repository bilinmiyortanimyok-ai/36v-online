using VeloBrawl.Logic.Database;
using VeloBrawl.Logic.Database.Account;
using VeloBrawl.Supercell.Titan.CommonUtils;

namespace VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_9;

public class LeaderboardMessage : PiranhaMessage
{
    private List<AccountModel>? _leaderboard;
    private int _leaderboardType;

    public LeaderboardMessage()
    {
        Helper.Skip();
    }

    public LeaderboardMessage(List<AccountModel> leaderboard, int leaderboardType)
    {
        _leaderboard = leaderboard;
        _leaderboardType = leaderboardType;
    }

    public override void Encode()
    {
        base.Encode();

        ByteStream.WriteBoolean(true);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteString("RU");

        if (_leaderboard == null || _leaderboard.Count == 0)
        {
            ByteStream.WriteVInt(2);
            
            for (int i = 0; i < 2; i++)
            {
                ByteStream.WriteVInt(0);
                ByteStream.WriteVInt(1);
                
                ByteStream.WriteVInt(1);
                ByteStream.WriteVInt(0);
                
                ByteStream.WriteVInt(1);
                ByteStream.WriteString("тестнет");
                
                ByteStream.WriteString(i == 0 ? "Жалко, но тут ничего нет" : "It's a pity, but there's nothing here");
                ByteStream.WriteVInt(0);
                ByteStream.WriteVInt(28000069);
                ByteStream.WriteVInt(43000005);
                ByteStream.WriteVInt(46000005);
                ByteStream.WriteVInt(0);
            }
        }
        else
        {
            ByteStream.WriteVInt(_leaderboard.Count);

            for (int i = 0; i < _leaderboard.Count; i++)
            {
                var account = _leaderboard[i];
                
                ByteStream.WriteVInt(0);
                ByteStream.WriteVInt((int)account.GetAccountId());
                
                ByteStream.WriteVInt(i + 1);
                ByteStream.WriteVInt((int)account.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.Trophies));
                
                ByteStream.WriteVInt(1);
                ByteStream.WriteString(account.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AvatarName).ToString());
                
                ByteStream.WriteString(account.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.AvatarName).ToString());
                ByteStream.WriteVInt(0);
                ByteStream.WriteVInt((int)account.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.PlayerThumbnailGlobalId));
                ByteStream.WriteVInt((int)account.GetFieldValueByAccountStructureParameterFromAccountModel(AccountStructure.NameColorGlobalId));
                ByteStream.WriteVInt(0);
                ByteStream.WriteVInt(0);
            }
        }

        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(1);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteString("RU");
    }

    public override int GetMessageType()
    {
        return 24403;
    }

    public override int GetServiceNodeType()
    {
        return 9;
    }
}