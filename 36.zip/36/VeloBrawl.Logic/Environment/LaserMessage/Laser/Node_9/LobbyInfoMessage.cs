using VeloBrawl.Logic.Database.Account;
using VeloBrawl.Supercell.Titan.CommonUtils;

namespace VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_9;

public class LobbyInfoMessage : PiranhaMessage
{
    private readonly AccountModel _accountModel;
    private readonly int _ping;
    private readonly int _playersOnline;

    public LobbyInfoMessage()
    {
        _accountModel = null!;
        _ping = 0;
        _playersOnline = 0;
    }

    public LobbyInfoMessage(AccountModel accountModel, int ping, int playersOnline)
    {
        _accountModel = accountModel;
        _ping = ping;
        _playersOnline = playersOnline;
    }

    public override void Encode()
    {
        base.Encode();

        string pingStatus;
        if (_ping >= 0 && _ping <= 49)
            pingStatus = "Отличный (" + _ping + "ms)";
        else if (_ping >= 50 && _ping <= 99)
            pingStatus = "Хороший (" + _ping + "ms)";
        else if (_ping >= 100 && _ping <= 199)
            pingStatus = "Удовлетворительный (" + _ping + "ms)";
        else if (_ping >= 200 && _ping <= 299)
            pingStatus = "Плохой (" + _ping + "ms)";
        else
            pingStatus = "Очень плохой (" + _ping + "ms)";

        string serverTime = DateTime.Now.ToString("HH:mm:ss");
        string serverDate = DateTime.Now.ToString("dd.MM.yyyy");

        string message = "t.me/projectbuzz\n" +
                        "Ping: " + pingStatus + "\n" +
                        "Online: " + _playersOnline + "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";

        ByteStream.WriteVInt(_playersOnline);
        ByteStream.WriteString(message);
        ByteStream.WriteVInt(0);
    }

    public override int GetMessageType()
    {
        return 23457;
    }

    public override int GetServiceNodeType()
    {
        return 27;
    }
}