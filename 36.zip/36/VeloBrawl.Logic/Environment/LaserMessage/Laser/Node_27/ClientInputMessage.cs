using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Input;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Manager;
using VeloBrawl.Supercell.Titan.CommonUtils;
using VeloBrawl.Titan.DataStream;
using VeloBrawl.Titan.Mathematical;

namespace VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_27;

public class ClientInputMessage : PiranhaMessage
{
    public int Checksum    { get; private set; }
    public int SubTick     { get; private set; }
    public int TimeMs      { get; private set; }
    public int PingMs      { get; private set; }
    public int BattleMs    { get; private set; }

    public ClientInputManager ClientInputManager { get; } = new();

    public override void Decode()
    {
        base.Decode();

        var bitStream = new BitStream(ByteStream.GetByteArray(), ByteStream.GetLength());

        Checksum = bitStream.ReadPositiveIntMax16383();
        SubTick  = bitStream.ReadPositiveIntMax1023();
        TimeMs   = bitStream.ReadPositiveIntMax8191();
        PingMs   = bitStream.ReadPositiveIntMax1023();
        BattleMs = bitStream.ReadPositiveIntMax1023();

        var count = LogicMath.Clamp(bitStream.ReadPositiveIntMax31(), 0, 30);

        for (var i = 0; i < count; i++)
        {
            var input = new ClientInput();
            input.Decode(bitStream);
            ClientInputManager.AddInput(input);
        }
    }

    public override void Clear()    => base.Clear();
    public override int GetMessageType()      => 10555;
    public override int GetServiceNodeType()  => 27;
}
