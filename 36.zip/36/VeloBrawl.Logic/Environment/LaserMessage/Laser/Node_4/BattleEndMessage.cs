using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Player;
using VeloBrawl.Titan.DataStream;
using VeloBrawl.Titan.DataStream.Helps;
using VeloBrawl.Titan.Mathematical;
using VeloBrawl.Titan.Mathematical.Data;

namespace VeloBrawl.Logic.Environment.LaserMessage.Laser.Node_4;

public class BattleEndMessage : PiranhaMessage
{
    private int _gameMode;
    private int _result;
    private int _trophiesReward;
    private int _tokensReward;
    private bool _isPvP;
    private LogicPlayer _ownPlayer = null!;
    private List<LogicPlayer> _players = null!;

    public void Setup(int gameMode, int result, bool isPvP, LogicPlayer ownPlayer, List<LogicPlayer> players,
        int trophiesReward = 0, int tokensReward = 10, int experienceReward = 0, int experience = 0)
    {
        _gameMode       = gameMode;
        _result         = result;
        _isPvP          = isPvP;
        _ownPlayer      = ownPlayer;
        _players        = players;
        _trophiesReward = trophiesReward;
        _tokensReward   = tokensReward;
    }

    public override void Encode()
    {
        base.Encode();

        var ownAccountId = _ownPlayer.GetAccountModel() != null
            ? (long)_ownPlayer.GetAccountModel().GetAccountId()
            : 0L;

        new LogicLong(0, (int)ownAccountId).Encode(ByteStream);
        new LogicLong(0, (int)ownAccountId).Encode(ByteStream);

        ByteStream.WriteVInt(_gameMode);
        ByteStream.WriteVInt(_result);

        ByteStream.WriteVInt(_tokensReward);
        ByteStream.WriteVInt(_trophiesReward);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(-1);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(3);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteBoolean(_isPvP);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteVInt(-1);
        ByteStream.WriteBoolean(false);

        var allPlayers = BuildPlayerList();
        ByteStream.WriteVInt(allPlayers.Count);

        foreach (var player in allPlayers)
        {
            var isOwn   = !player.IsBot() && player == _ownPlayer;
            var isEnemy = player.GetTeamIndex() != _ownPlayer.GetTeamIndex();

            ByteStream.WriteBoolean(isOwn);
            ByteStream.WriteBoolean(isEnemy);
            ByteStream.WriteBoolean(false);

            ByteStream.WriteByte(1);
            ByteStreamHelper.WriteDataReference(ByteStream,
                GlobalId.CreateGlobalId(16, player.HeroInfo.Count > 0 ? player.HeroInfo[0] : 0));

            ByteStream.WriteByte(1);
            ByteStreamHelper.WriteDataReference(ByteStream,
                player.HeroInfo.Count > 3 && player.HeroInfo[3] > 0 ? 29000000 + player.HeroInfo[3] : 0);

            ByteStream.WriteByte(1);
            ByteStream.WriteVInt(0);

            ByteStream.WriteByte(1);
            ByteStream.WriteVInt(player.HeroInfo.Count > 1 ? player.HeroInfo[1] + 1 : 1);

            ByteStream.WriteByte(1);
            ByteStream.WriteVInt(0);

            ByteStream.WriteVInt(0);
            ByteStream.WriteVInt(0);

            ByteStream.WriteBoolean(isOwn);
            if (isOwn)
                new LogicLong(0, (int)(player.GetAccountModel()?.GetAccountId() ?? 0)).Encode(ByteStream);

            var pd = player.GetPlayerDisplayData();
            if (pd != null) pd.Encode(ByteStream);
            else { var f = new PlayerDisplayData(); f.SetAvatarName("Bot"); f.Encode(ByteStream); }

            ByteStream.WriteBoolean(false);
            ByteStream.WriteByte(0);
            ByteStream.WriteByte(0);
            ByteStream.WriteShort(0);
            ByteStream.WriteShort(0);
            ByteStream.WriteInt(0);
            ByteStream.WriteInt(0);
            ByteStreamHelper.WriteDataReference(ByteStream, 0);
        }

        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(1);
        ByteStream.WriteVInt(1);
        ByteStream.WriteVInt(1);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteVInt(0);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteVInt(0);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteBoolean(false);
        ByteStream.WriteVInt(0);
        ByteStream.WriteVInt(0);
        ByteStream.WriteBoolean(true);
        ByteStream.WriteVInt(6);
        for (byte i = 0; i < 6; i++) { ByteStream.WriteByte(i); ByteStream.WriteByte(i); }
        ByteStream.WriteBoolean(false);
    }

    private List<LogicPlayer> BuildPlayerList()
    {
        var result = new List<LogicPlayer>(_players);

        while (result.Count < 6)
        {
            var fake = new LogicPlayer();
            fake.SetPlayerIndex(result.Count);
            fake.SetTeamIndex(result.Count % 2);
            fake.SetBot(true);
            fake.HeroInfo.Add(0);
            fake.HeroInfo.Add(1);
            fake.HeroInfo.Add(0);
            fake.HeroInfo.Add(0);
            var pd = new PlayerDisplayData();
            pd.SetAvatarName("Bot");
            fake.SetPlayerDisplayData(pd);
            result.Add(fake);
        }

        return result;
    }

    public override void Destruct() => base.Destruct();
    public override int GetMessageType() => 23456;
    public override int GetServiceNodeType() => 4;
}
