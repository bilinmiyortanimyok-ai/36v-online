using Newtonsoft.Json;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;

namespace VeloBrawl.Logic.Environment.LaserMessage.Sepo.Avatar;

[JsonObject(MemberSerialization.OptIn)]
public class ClientAvatar
{
    [JsonProperty] public long AccountId;
    [JsonProperty] public string Name = "Brawler";
    [JsonProperty] public bool NameSetByUser;
    [JsonProperty] public int Gold;
    [JsonProperty] public int Diamonds;
    [JsonProperty] public int Tokens;
    [JsonProperty] public int StarTokens;
    [JsonProperty] public int StarPoints;
    [JsonProperty] public int HighestTrophies;
    [JsonProperty] public int RollsSinceGoodDrop;
    [JsonProperty] public double ForcedDropsChance;
    [JsonProperty] public List<Hero> Heroes = new();
    [JsonProperty] public List<int> Starpowers = new();
    [JsonProperty] public List<int> SelectedStarpowers = new();

    public int Trophies => Heroes.Sum(h => h.Trophies);

    public int GetUnlockedHeroesCount() => Heroes.Count;

    public void UnlockHero(int characterId, int cardId) => Heroes.Add(new Hero(characterId, cardId));

    public bool HasHero(int characterId) => Heroes.Find(x => x.CharacterId == characterId) != null;

    public Hero? GetHero(int characterId) => Heroes.Find(x => x.CharacterId == characterId);

    public bool UseDiamonds(int count)
    {
        if (count > Diamonds) return false;
        Diamonds -= count;
        return true;
    }

    public void AddDiamonds(int count) => Diamonds += count;

    public void AddGold(int count) => Gold += count;

    public bool UseGold(int count)
    {
        if (count > Gold) return false;
        Gold -= count;
        return true;
    }

    public bool UseTokens(int count)
    {
        if (count > Tokens) return false;
        Tokens -= count;
        return true;
    }

    public bool UseStarTokens(int count)
    {
        if (count > StarTokens) return false;
        StarTokens -= count;
        return true;
    }

    public void AddStarTokens(int count) => StarTokens += count;
    public void AddTrophies(int t) => HighestTrophies = Math.Max(HighestTrophies, Trophies + t);
}
