using VeloBrawl.Titan.DataStream;
using VeloBrawl.Titan.Mathematical.Data;

namespace VeloBrawl.Logic.Environment.LaserMessage.Sepo.Input;

public class ClientInput
{
    public long OwnSessionId { get; set; }

    public int Index    { get; private set; }
    public int Type     { get; private set; }
    public int X        { get; private set; }
    public int Y        { get; private set; }
    public bool IsMoving  { get; private set; }
    public bool HasTarget { get; private set; }
    public int TargetId   { get; private set; }
    public int PinIndex   { get; private set; }
    public int Emote      { get; private set; }

    public void Decode(BitStream bitStream)
    {
        Index    = bitStream.ReadPositiveIntMax32767();
        Type     = bitStream.ReadPositiveIntMax15();
        X        = bitStream.ReadIntMax32767();
        Y        = bitStream.ReadIntMax32767();
        IsMoving = bitStream.ReadBoolean();
        var flag2 = bitStream.ReadBoolean();

        if (Type == 11)
        {
            Emote = bitStream.ReadPositiveVIntMax255();
            if (!IsMoving) return;
        }
        else if (Type == 9)
        {
            PinIndex = bitStream.ReadPositiveIntMax7();
        }

        if (IsMoving)
        {
            HasTarget = bitStream.ReadBoolean();
            if (HasTarget)
            {
                var instanceId = bitStream.ReadPositiveIntMax16383();
                TargetId = GlobalId.CreateGlobalId(1, instanceId);
            }
        }
    }
}
