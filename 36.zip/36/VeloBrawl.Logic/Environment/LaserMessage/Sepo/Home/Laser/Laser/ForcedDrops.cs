using VeloBrawl.Titan.DataStream;

namespace VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;

public class ForcedDrops
{
    public int Field0;
    public int Field1;
    public List<int> Items = new();

    public ForcedDrops() { }

    public ForcedDrops(ByteStream stream)
    {
        Field0 = stream.ReadVInt();
        Field1 = stream.ReadVInt();
        int count = stream.ReadVInt();
        for (int i = 0; i < count; i++)
            Items.Add(stream.ReadVInt());
    }

    public void Encode(ByteStream stream)
    {
        stream.WriteVInt(Field0);
        stream.WriteVInt(Field1);
        stream.WriteVInt(Items.Count);
        foreach (int item in Items)
            stream.WriteVInt(item);
    }
}
