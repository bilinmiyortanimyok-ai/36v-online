using Newtonsoft.Json;
using VeloBrawl.Titan.DataStream;
using VeloBrawl.Titan.DataStream.Helps;
using VeloBrawl.Titan.Mathematical.Data;

namespace VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;

[JsonObject(MemberSerialization.OptIn)]
public class Quest
{
    [JsonProperty] public int MissionType { get; set; }
    [JsonProperty] public int CurrentGoal { get; set; }
    [JsonProperty] public int QuestGoal { get; set; }
    [JsonProperty] public int GameModeVariation { get; set; }
    [JsonProperty] public bool IsDailyQuest { get; set; }
    [JsonProperty] public bool BrawlPassExclusive { get; set; }
    [JsonProperty] public bool QuestSeen { get; set; }
    [JsonProperty] public int CharacterId { get; set; }
    [JsonProperty] public int Reward { get; set; }
    [JsonProperty] public int Progress { get; set; }

    public Quest Clone() => new Quest
    {
        MissionType = MissionType,
        CurrentGoal = CurrentGoal,
        QuestGoal = QuestGoal,
        GameModeVariation = GameModeVariation,
        IsDailyQuest = IsDailyQuest,
        BrawlPassExclusive = BrawlPassExclusive,
        QuestSeen = QuestSeen,
        CharacterId = CharacterId,
        Reward = Reward,
        Progress = Progress
    };

    public void Encode(ByteStream byteStream)
    {
        byteStream.WriteVInt(0);
        byteStream.WriteVInt(1);
        byteStream.WriteVInt(MissionType);
        byteStream.WriteVInt(CurrentGoal);
        byteStream.WriteVInt(QuestGoal);
        byteStream.WriteVInt(Reward);
        byteStream.WriteVInt(0);
        byteStream.WriteVInt(0);
        byteStream.WriteVInt(0);
        byteStream.WriteVInt(IsDailyQuest ? 1 : -1);
        byteStream.WriteBoolean(BrawlPassExclusive);
        byteStream.WriteBoolean(QuestSeen);
        ByteStreamHelper.WriteDataReference(byteStream, CharacterId);
        byteStream.WriteVInt(GameModeVariation);
        byteStream.WriteVInt(Progress);
        byteStream.WriteVInt(0);
    }
}
