using Newtonsoft.Json;
using VeloBrawl.Titan.DataStream;
using VeloBrawl.Titan.DataStream.Helps;

namespace VeloBrawl.Logic.Environment.LaserMessage.Sepo.Home.Laser.Laser;

[JsonObject(MemberSerialization.OptIn)]
public class Hero
{
    [JsonProperty] public int CharacterId;
    [JsonProperty] public int CardId;
    [JsonProperty] public int Trophies;
    [JsonProperty] public int HighestTrophies;
    [JsonProperty] public int PowerPoints;
    [JsonProperty] public int PowerLevel;
    [JsonProperty] public bool HasStarpower;
    [JsonProperty] public bool IsNew;

    public Hero() { }

    public Hero(int characterId, int cardId)
    {
        CharacterId = characterId;
        CardId = cardId;
        PowerLevel = 0;
    }

    public void AddTrophies(int trophies)
    {
        Trophies += trophies;
        HighestTrophies = Math.Max(HighestTrophies, Trophies);
    }

    public void Encode(ByteStream stream)
    {
        ByteStreamHelper.WriteDataReference(stream, CharacterId);
        ByteStreamHelper.WriteDataReference(stream, 0);
        stream.WriteVInt(Trophies);
        stream.WriteVInt(HighestTrophies);
        stream.WriteVInt(PowerLevel + 1 + (HasStarpower ? 1 : 0));
    }
}
