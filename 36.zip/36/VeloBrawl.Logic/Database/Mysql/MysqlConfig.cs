using Newtonsoft.Json;

namespace VeloBrawl.Logic.Database.Mysql;

public class MysqlConfig
{
    [JsonProperty("enabled")] public bool Enabled { get; set; } = false;
    [JsonProperty("host")] public string Host { get; set; } = "127.0.0.1";
    [JsonProperty("port")] public int Port { get; set; } = 3306;
    [JsonProperty("username")] public string Username { get; set; } = "";
    [JsonProperty("password")] public string Password { get; set; } = "";
    [JsonProperty("database")] public string Database { get; set; } = "";

    public static MysqlConfig LoadFromFile(string path)
    {
        if (!File.Exists(path))
        {
            var def = new MysqlConfig();
            File.WriteAllText(path, JsonConvert.SerializeObject(def, Formatting.Indented));
            return def;
        }
        return JsonConvert.DeserializeObject<MysqlConfig>(File.ReadAllText(path))!;
    }
}
