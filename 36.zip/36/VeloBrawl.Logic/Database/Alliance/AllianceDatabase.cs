using MySql.Data.MySqlClient;
using Newtonsoft.Json;
using VeloBrawl.Logic.Environment.LaserMessage.Sepo.Alliance;
using VeloBrawl.Titan.Graphic;

namespace VeloBrawl.Logic.Database.Alliance;

public class AllianceDatabase : AllianceModel
{
    private string _connectionString = null!;
    private Dictionary<long, AllianceModel> _cache = new();

    public AllianceDatabase(string? filePath, bool loadByBackup = false)
    {
    }

    public void InitMysql(string host, int port, string user, string password, string database)
    {
        var builder = new MySqlConnectionStringBuilder
        {
            Server = host,
            Port = (uint)port,
            UserID = user,
            Password = password,
            Database = database,
            SslMode = MySqlSslMode.Disabled,
            CharacterSet = "utf8mb4"
        };
        _connectionString = builder.ToString();

        using var conn = Open();
        conn.Open();
        using var cmd = new MySqlCommand(@"
            CREATE TABLE IF NOT EXISTS alliances (
                Id BIGINT PRIMARY KEY,
                Name VARCHAR(255) NOT NULL DEFAULT '',
                Trophies INT NOT NULL DEFAULT 0,
                Data LONGTEXT NOT NULL
            ) CHARACTER SET utf8mb4;", conn);
        cmd.ExecuteNonQuery();

        LoadAllToCache();
        ConsoleLogger.WriteTextWithPrefix(ConsoleLogger.Prefixes.Start,
            $"Database-element started! Information: element name: {GetType().Name}; database buffer length: {_cache.Count}.");
    }

    private MySqlConnection Open() => new(_connectionString);

    private void LoadAllToCache()
    {
        _cache.Clear();
        using var conn = Open();
        conn.Open();
        using var cmd = new MySqlCommand("SELECT Id, Data FROM alliances", conn);
        var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            try
            {
                var model = JsonConvert.DeserializeObject<AllianceModel>((string)reader["Data"]);
                if (model != null)
                    _cache[Convert.ToInt64(reader["Id"])] = model;
            }
            catch { }
        }
    }

    public void CyclingLoadDataFromFile(int perSec)
    {
        Task.Run(async () =>
        {
            while (true)
            {
                await Task.Delay(perSec * 1000);
                LoadDataFromFile(true);
            }
        });
    }

    public void LoadDataFromFile(bool reloaded = false)
    {
        LoadAllToCache();
        ConsoleLogger.WriteTextWithPrefix(reloaded ? ConsoleLogger.Prefixes.Load : ConsoleLogger.Prefixes.Start,
            $"Database-element {(reloaded ? "reloaded" : "started")}! Information: element name: {GetType().Name}; database buffer length: {_cache.Count}.");
    }

    public AllianceModel CreateAlliance(AllianceModel allianceModel, long allianceId = -1)
    {
        allianceId = allianceId < 0 ? GetNewAllianceId() : allianceId;
        try
        {
            allianceModel.SetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceId, allianceId);
            var json = JsonConvert.SerializeObject(allianceModel, Formatting.None);
            var name = allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceName)?.ToString() ?? "";
            using var conn = Open();
            conn.Open();
            using var cmd = new MySqlCommand(
                "INSERT INTO alliances (Id, Name, Data) VALUES (@id, @name, @data) ON DUPLICATE KEY UPDATE Name=@name, Data=@data", conn);
            cmd.Parameters.AddWithValue("@id", allianceId);
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@data", json);
            cmd.ExecuteNonQuery();
            _cache[allianceId] = allianceModel;
        }
        catch { }
        return allianceModel;
    }

    public AllianceModel LoadAlliance(long id)
    {
        if (id <= 0) return null!;
        if (_cache.TryGetValue(id, out var cached))
            return cached;
        try
        {
            using var conn = Open();
            conn.Open();
            using var cmd = new MySqlCommand("SELECT Data FROM alliances WHERE Id=@id", conn);
            cmd.Parameters.AddWithValue("@id", id);
            var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                var model = JsonConvert.DeserializeObject<AllianceModel>((string)reader["Data"])!;
                _cache[id] = model;
                return model;
            }
        }
        catch { }
        return null!;
    }

    public AllianceModel SetAllianceParameter(long allianceId, AllianceStructure allianceStructure, object value)
    {
        var model = LoadAlliance(allianceId);
        if (model == null!) return null!;
        model.SetFieldValueByAllianceStructureParameterFromAllianceModel(allianceStructure, value);
        return OnAssistByAllianceInFile(model, true, allianceId);
    }

    public object GetAllianceParameter(long allianceId, AllianceStructure allianceStructure)
    {
        var model = LoadAlliance(allianceId);
        if (model != null!)
            return model.GetFieldValueByAllianceStructureParameterFromAllianceModel(allianceStructure);
        return null!;
    }

    public AllianceModel OnAssistByAllianceInFile(AllianceModel allianceModel, bool wasReplace, long allianceId = -1)
    {
        allianceId = allianceId < 0
            ? Convert.ToInt64(allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceId))
            : allianceId;

        if (wasReplace)
            _cache[allianceId] = allianceModel;
        else
            _cache.TryAdd(allianceId, allianceModel);

        try
        {
            var json = JsonConvert.SerializeObject(allianceModel, Formatting.None);
            var name = allianceModel.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceName)?.ToString() ?? "";
            using var conn = Open();
            conn.Open();
            using var cmd = new MySqlCommand(
                "INSERT INTO alliances (Id, Name, Data) VALUES (@id, @name, @data) ON DUPLICATE KEY UPDATE Name=@name, Data=@data", conn);
            cmd.Parameters.AddWithValue("@id", allianceId);
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@data", json);
            cmd.ExecuteNonQuery();
        }
        catch { }

        return allianceModel;
    }

    public string ConvertDictionaryToJson(Dictionary<long, AllianceModel>? onRamBase = null!)
    {
        return JsonConvert.SerializeObject(onRamBase ?? _cache);
    }

    public Dictionary<long, AllianceModel> ConvertJsonToDictionary(string json, bool localUs = false)
    {
        return localUs ? _cache : JsonConvert.DeserializeObject<Dictionary<long, AllianceModel>>(json)!;
    }

    public long GetMaxAllianceId()
    {
        if (_cache.Count > 0) return _cache.Keys.Max();
        try
        {
            using var conn = Open();
            conn.Open();
            using var cmd = new MySqlCommand("SELECT COALESCE(MAX(Id),0) FROM alliances", conn);
            return Convert.ToInt64(cmd.ExecuteScalar());
        }
        catch { return 0; }
    }

    public long GetNewAllianceId() => GetMaxAllianceId() + 1;

    public List<AllianceModel> GetRandomAllianceModels(int maxRequiredTrophies)
    {
        return _cache.Values
            .Where(a =>
            {
                var req = a.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceRequiredScore);
                return req == null! || Convert.ToInt32(req) <= maxRequiredTrophies;
            })
            .OrderBy(_ => Guid.NewGuid())
            .Take(20)
            .ToList();
    }

    public List<AllianceModel> GetAllianceModelsByName(string name)
    {
        return _cache.Values
            .Where(a =>
            {
                var n = a.GetFieldValueByAllianceStructureParameterFromAllianceModel(AllianceStructure.AllianceName)?.ToString() ?? "";
                return n.Contains(name, StringComparison.OrdinalIgnoreCase);
            })
            .Take(20)
            .ToList();
    }
}
