namespace VeloBrawl.Logic.Bot;

public static class BotBridge
{
    public static string BotUsername { get; set; } = "гпт";
}
